package com.sysco.response;

import lombok.Data;

/**
 * Created by james.zhu on 2018/9/21.
 */
@Data
public class ResBracket {
    private String bracket1;
    private String bracket2;
    private String bracket3;
    private String bracket4;
    private String bracket5;
    private String bracket6;
    private String bracket7;
    private String bracket8;
}
