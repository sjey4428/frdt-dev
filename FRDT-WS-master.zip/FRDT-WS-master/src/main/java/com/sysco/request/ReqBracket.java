package com.sysco.request;

import lombok.Data;

/**
 * Created by james.zhu on 2018/9/21.
 */
@Data
public class ReqBracket {
    private String _bracket_one;
    private String _bracket_two;
    private String _bracket_three;
    private String _bracket_four;
    private String _bracket_five;
    private String _bracket_six;
    private String _bracket_seven;
    private String _bracket_eight;
}
