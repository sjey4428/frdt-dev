package com.sysco.entity;

import lombok.Data;

/**
 * Created by chunyu.chen on 9/12/2018.
 */
@Data
public class Documents {
    private String docName;
}
