package com.sysco.entity;

import lombok.Data;

/**
 * Created by chunyu.chen on 9/26/2018.
 */
@Data
public class VendorFileUrl {
    private String syscoSuvc;
    private String fileUrl;
    private String status;
}
